import java.io.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class viewv2 extends HttpServlet{

    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/ecell";

    static final String USER = "root";
    static final String PASSWORD = "vikash1234";
    
    public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException{
        
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        String title = "Delete Record";

       

        try{
            Class.forName(JDBC_DRIVER);
            Connection con = DriverManager.getConnection(DB_URL,USER,PASSWORD);
            Statement stm1 = con.createStatement();

             String sql;
            sql = "SELECT * FROM pitch";
            
            ResultSet rs = stm1.executeQuery(sql);


            out.println("<head><style>th,tr,td {border: 1px solid black; text-align: center;}</style></head><body><h2>Pitch Details</h2><table style=\"border: 1px solid black; text-align: center;\"><thead style=\"border: 1px solid black; text-align: center;\"><tr><th>Founder Name</th><th>Company Name</th><th>Valuation</th><th>Category</th><th>Due Diligence Status</th><th>Current Ask</th></tr></thead>");
            out.println("<tbody style=\"border: 1px solid black; text-align: center;\">");
            int i=1;

            while(rs.next()){
                out.println("<tr>");
                out.print("<td>"+rs.getString("fname")+"</td>");
                out.print("<td>"+rs.getString("cname")+"</td>");
               out.print("<td>"+rs.getString("valuation")+"</td>");
                out.print("<td>"+rs.getString("category")+"</td>"); 
                out.print("<td>"+rs.getString("dd_status")+"</td>");
               out.print("<td>"+rs.getString("current_ask")+"</td>");
                out.println("</tr>");
                i++;           
            }

            rs.close();
            stm1.close();

            out.println("</tbody>");
            out.println("</body>\n</html>");
        

            String cname = req.getParameter("cname");            
            String dd_status = req.getParameter("dd_status");

           
                PreparedStatement stm = con.prepareStatement("UPDATE pitch SET dd_status=? WHERE cname=?");

                stm.setString(1,req.getParameter("dd_status"));
                stm.setString(2,req.getParameter("cname"));
                
                stm.executeUpdate();
                stm.close();
            
          
           
            con.close();

            res.sendRedirect("success_admin.html");
        }
        catch(SQLException e){
            System.out.println(e);
            out.println("<body>Database Error</body>");
            out.println("</html>");
        }
        catch(Exception e){
            System.out.println(e);
            out.println("<body>Updation of record Unsuccesfull</body>");
            out.println("</html>");
        }
    }
}