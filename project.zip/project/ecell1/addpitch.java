import java.io.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class addpitch extends HttpServlet{
    
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/ecell";

    static final String USER = "root";
    static final String PASSWORD = "vikash1234";

    public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        String title = "Add Record";

        HttpSession session = req.getSession(false);

        out.println( 
        "<!DOCTYPE html>\n<html>\n<head>\n<title>"+title+"</title>\n<meta charset='UTF-8'>\n</head>"
        );

        try{
            Class.forName(JDBC_DRIVER);

            String email = (String)session.getAttribute("email1");

            Connection con = DriverManager.getConnection(DB_URL,USER,PASSWORD);

            PreparedStatement stm = con.prepareStatement("INSERT INTO pitch VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            stm.setString(1,req.getParameter("fname"));
            stm.setString(2,req.getParameter("cname"));
            stm.setString(3,req.getParameter("phone_no"));
            stm.setString(4,req.getParameter("cofounder"));
            stm.setString(5,req.getParameter("valuation"));
            stm.setString(6,req.getParameter("ebita"));
            stm.setString(7,req.getParameter("sales_2019"));
            stm.setString(8,req.getParameter("sales_2020"));
            stm.setString(9,req.getParameter("sales_2021"));
            stm.setString(10,req.getParameter("sales_2022"));
            stm.setString(11,req.getParameter("sales_2023"));
            stm.setString(12, req.getParameter("month_1"));
            stm.setString(13,req.getParameter("month_2"));
            stm.setString(14,req.getParameter("month_3"));
            stm.setString(15,req.getParameter("month_4"));
            stm.setString(16, req.getParameter("month_5"));
            stm.setString(17,req.getParameter("month_6"));
            stm.setString(18,req.getParameter("cac"));
            stm.setString(19,req.getParameter("cog"));
            stm.setString(20, req.getParameter("operations"));
            stm.setString(21,req.getParameter("misc"));
            stm.setString(22,req.getParameter("net_profit"));
            stm.setString(23,req.getParameter("gross_profit"));
            stm.setString(24, req.getParameter("video_url"));
            stm.setString(25,req.getParameter("category"));
            stm.setString(26,req.getParameter("founder_role"));
            stm.setString(27, req.getParameter("founder_equity"));
            stm.setString(28,req.getParameter("investor_equity"));
            stm.setString(29,req.getParameter("dd_status"));
            stm.setString(30,req.getParameter("current_ask"));
            stm.setString(31, email); 


            stm.executeUpdate();

            stm.close();
            con.close();

            res.sendRedirect("success_pitch.html");
        }
        catch(SQLException e){
            System.out.println(e);
            out.println("<body>Database Error</body>");
            out.println("</html>");
        }
        catch(Exception e){
            System.out.println(e);
            out.println("<body>Submission of Pitch Unsuccesfull</body>");
            out.println("</html>");
        }
    }
}