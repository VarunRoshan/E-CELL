import java.io.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class investordetails extends HttpServlet{
    
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/ecell";

    static final String USER = "root";
    static final String PASSWORD = "vikash1234";

    public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        String title = "View Records";

        out.println( 
        "<!DOCTYPE html>\n<html>\n<head>\n<title>"+title+"</title>\n<meta charset='UTF-8'>\n</head>"
        );

        try{
            Class.forName(JDBC_DRIVER);

            Connection con = DriverManager.getConnection(DB_URL,USER,PASSWORD);

            Statement stm = con.createStatement();
            String sql;
            sql = "SELECT * FROM investor where fname = \'"+req.getParameter("fname")+"\'";        
            ResultSet rs = stm.executeQuery(sql);


            out.println("<head><style>th,tr,td {border: 1px solid black; text-align: center;}</style></head><body><h2>Personal Details</h2><table style=\"border: 1px solid black; text-align: center;\"><thead style=\"border: 1px solid black; text-align: center;\"><tr><th>First Name</th><th>Last Name</th><th>Age</th><th>Nationality</th><th>Email</th><th>Phone No</th><th>Aadhar ID</th><th>PAN Card No</th><th>Education</th><th>Password</th><th>Current Company</th><th>Awards Won</th><th>Domain Specification</th></tr></thead>");
            out.println("<tbody style=\"border: 1px solid black; text-align: center;\">");
            int i=1;

            while(rs.next()){
                out.println("<tr>");
                out.print("<td>"+rs.getString("fname")+"</td>");
                out.print("<td>"+rs.getString("lname")+"</td>");                
                out.print("<td>"+rs.getString("age")+"</td>");
                out.print("<td>"+rs.getString("nationality")+"</td>");
                out.print("<td>"+rs.getString("email")+"</td>"); 
                out.print("<td>"+rs.getString("phone_no")+"</td>");
                out.print("<td>"+rs.getString("aadhar")+"</td>");
                out.print("<td>"+rs.getString("pan")+"</td>"); 
                out.print("<td>"+rs.getString("education")+"</td>");
                out.print("<td>"+rs.getString("password")+"</td>");
                out.print("<td>"+rs.getString("currcomp")+"</td>");
                out.print("<td>"+rs.getString("awards")+"</td>");
                out.print("<td>"+rs.getString("dspec")+"</td>"); 
            
                out.println("</tr>");         
            }

            rs.close();
            stm.close();
            con.close();

            out.println("</tbody>");
            out.println("</body>\n</html>");
        }
        catch(SQLException e){
            System.out.println(e);
            out.println("<body>Database Error</body>");
            out.println("</html>");
        }
        catch(Exception e){
            System.out.println(e);
            out.println("<body>Viewing of record Unsuccesfull</body>");
            out.println("</html>");
        }
    }
}