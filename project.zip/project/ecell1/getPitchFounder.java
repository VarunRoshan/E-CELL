import java.io.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class getPitchFounder extends HttpServlet{
    
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/ecell";

    static final String USER = "root";
    static final String PASSWORD = "vikash1234";

    String fname, cname, phone_no, cofounder, valuation, ebita, sales_2019, sales_2020, sales_2021, sales_2022, sales_2023, month_1, month_2, month_3, month_4, month_5, month_6, cac, cog, operations, misc, net_profit, gross_profit, video_url, category, founder_role, founder_equity, investor_equity, current_ask, status, mail;

    public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        String title = "View Records";

        out.println( 
        "<!DOCTYPE html>\n<html>\n<head>\n<title>"+title+"</title>\n<meta charset='UTF-8'>\n</head>"
        );

        try{
            Class.forName(JDBC_DRIVER);

            Connection con = DriverManager.getConnection(DB_URL,USER,PASSWORD);

            Statement stm = con.createStatement();
            String sql;

            sql = "SELECT * FROM pitch where cname = '"+req.getParameter("cname")+"'";
            
            
            ResultSet rs = stm.executeQuery(sql);

            

            while(rs.next()){
                fname = rs.getString("fname");
                cname = rs.getString("cname");
                phone_no = rs.getString("phone_no");
                cofounder = rs.getString("cofounder");
                valuation = rs.getString("valuation");
                ebita = rs.getString("ebita");
                sales_2019 = rs.getString("sales_2019");
                sales_2020 = rs.getString("sales_2020");
                sales_2021 = rs.getString("sales_2021");
                sales_2022 = rs.getString("sales_2022");
                sales_2023 = rs.getString("fname");
                month_1 = rs.getString("month_1");
                month_2 = rs.getString("month_2");
                month_3 = rs.getString("month_3");
                month_4 = rs.getString("month_4");
                month_5 = rs.getString("month_5");
                month_6 = rs.getString("month_6");
                cac = rs.getString("cac");
                cog = rs.getString("cog");
                operations = rs.getString("operations");
                misc = rs.getString("misc");
                net_profit = rs.getString("net_profit");
                gross_profit = rs.getString("gross_profit");
                video_url = rs.getString("video_url");
                category = rs.getString("category");
                founder_role = rs.getString("founder_role");
                founder_equity = rs.getString("founder_equity");
                investor_equity = rs.getString("investor_equity");
                status = rs.getString("dd_status");
                current_ask = rs.getString("current_ask");   
                mail = rs.getString("email");    
            }

            
            String url = "pitchFounder.html?fname=" + fname +  "&cname=" + cname +  "&phone_no=" + phone_no + "&cofounder=" + cofounder + "&valuation=" + valuation + "&ebita=" + ebita + "&sales_2019=" + sales_2019 + "&sales_2020=" + sales_2020 + "&sales_2021=" + sales_2021 + "&sales_2022=" + sales_2022 + "&sales_2023=" + sales_2023 + "&month_1=" + month_1 + "&month_2=" + month_2 + "&month_3=" + month_3 + "&month_4=" + month_4 + "&month_5=" + month_5 + "&month_6=" + month_6 + "&cac=" + cac + "&cog=" + cog + "&operations=" + operations + "&misc=" + misc + "&net_profit=" + net_profit + "&gross_profit=" + gross_profit + "&video_url=" + video_url + "&category=" + category + "&founder_role=" + founder_role + "&founder_equity=" + founder_equity + "&investor_equity=" + investor_equity + "&dd_status=" + status + "&current_ask=" + current_ask + "&email=" + mail ;

            // req.setAttribute("id1", num1);
            // req.setAttribute("id2", num2);
            // req.setAttribute("id3", num3);
            // req.setAttribute("id4", num4);
            // req.getRequestDispatcher("/random1.html").forward(req,res);

            
            res.sendRedirect(url);
                
            rs.close();
            stm.close();
            con.close();

            out.println("</tbody>");
            out.println("Searched for a  record Successfully");
            out.println("</body>\n</html>");
        }
        catch(SQLException e){
            System.out.println(e);
            out.println("<body>Database Error</body>");
            out.println("</html>");
        }
        catch(Exception e){
            System.out.println(e);
            out.println("<body>Searching of record Unsuccesfull</body>");
            out.println("</html>");
        }
    }
}