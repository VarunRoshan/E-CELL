import java.io.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class viewInvestorProfile extends HttpServlet{
    
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/ecell";

    static final String USER = "root";
    static final String PASSWORD = "vikash1234";

    public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{

        HttpSession session = req.getSession(false);
        if(session == null)
            res.sendRedirect("http://localhost:8080/ecell1/login.html");
        else{
            res.setContentType("text/html");
            PrintWriter out = res.getWriter();
            String title = "View Records";

            out.println( 
            "<!DOCTYPE html>\n<html>\n<head><link rel='stylesheet' href='index.css'>\n<title>"+title+"</title>\n<meta charset='UTF-8'>\n</head>"
            );

            String email = (String)session.getAttribute("email1");

            try{
                Class.forName(JDBC_DRIVER);

                Connection con = DriverManager.getConnection(DB_URL,USER,PASSWORD);

                Statement stm = con.createStatement();
                String sql;
                sql = "SELECT * FROM investor where email = \'"+ email + "'";        
                ResultSet rs = stm.executeQuery(sql);


                out.println("<head><link rel='stylesheet' href='index.css'><title>Profile</title></head><body class='bg'><nav style='padding-top: 30px;'><ul><h1 style='display:inline; margin:40px 0px 10px 20px; color:white;'>Entrepreneurship Cell</h1><li style='vertical-align: middle; float: right; '><a href='http://localhost:8080/ecell1/viewInvestorProfile'>Profile</a></li><li style='vertical-align: middle; float: right; '><a href='http://localhost:8080/ecell1/searchHome.html'>View Pitch</a></li><li style='vertical-align: middle; float: right; '><a href='investor.html'>Home</a></li></ul></nav><h2>Personal Details</h2><table id='customers'>");
                out.println("<tbody>");

                while(rs.next()){
                    out.print("<tr><td>First Name</td><td>"+rs.getString("fname")+"</td></tr>");
                    out.print("<tr><td>Last Name</td><td>"+rs.getString("lname")+"</td></tr>");                
                    out.print("<tr><td>Age</td><td>"+rs.getString("age")+"</td></tr>");
                    out.print("<tr><td>Nationality</td><td>"+rs.getString("nationality")+"</td></tr>");
                    out.print("<tr><td>Email</td><td>"+rs.getString("email")+"</td></tr>"); 
                    out.print("<tr><td>Phone No</td><td>"+rs.getString("phone_no")+"</td></tr>");
                    out.print("<tr><td>Aadhar</td><td>"+rs.getString("aadhar")+"</td></tr>");
                    out.print("<tr><td>Pan</td><td>"+rs.getString("pan")+"</td></tr>"); 
                    out.print("<tr><td>Education</td><td>"+rs.getString("education")+"</td></tr>");
                    out.print("<tr><td>Password</td><td>"+rs.getString("password")+"</td></tr>");
                    out.print("<tr><td>Current Company</td><td>"+rs.getString("currcomp")+"</td></tr>");
                    out.print("<tr><td>Awards</td><td>"+rs.getString("awards")+"</td></tr>");
                    out.print("<tr><td>Domain Speciality</td><td>"+rs.getString("dspec")+"</td></tr>");        
                }

                rs.close();
                stm.close();
                con.close();

                out.println("</tbody>");
                out.println("<a href='updateinvestor.html'><button>Update Profile</button></a>");
                out.println("<a href='http://localhost:8080/ecell1/logout'><button>Logout</button></a>");
                out.println("</body>\n</html>");
            }
            catch(SQLException e){
                System.out.println(e);
                out.println("<body>Database Error</body>");
                out.println("</html>");
            }
            catch(Exception e){
                System.out.println(e);
                out.println("<body>Viewing of record Unsuccesfull</body>");
                out.println("</html>");
            }
        }
    }
}