import java.io.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class searchpitch_evaluation extends HttpServlet{
    
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/ecell";

    static final String USER = "root";
    static final String PASSWORD = "vikash1234";

    public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        String title = "Search Pitch";

        out.println( 
        "<!DOCTYPE html>\n<html>\n<head>\n<title>"+title+"</title>\n<link rel=\"stylesheet\" href=\"index.css\" />\n<meta charset='UTF-8'>\n</head>"
        );

        
        try{
            Class.forName(JDBC_DRIVER);

            Connection con = DriverManager.getConnection(DB_URL,USER,PASSWORD);

            Statement stm = con.createStatement();
            String sql;
            sql = "SELECT * FROM pitch where valuation > '" + Integer.parseInt(req.getParameter("valuation")) + "'";;
            
            ResultSet rs = stm.executeQuery(sql);


            out.println("<head><link rel='stylesheet' href='index.css'></head><body class='bg'><nav style='padding-top: 30px;'><ul><h1 style='display:inline; margin:40px 0px 10px 20px; color:white;'>Entrepreneurship Cell</h1><li style='vertical-align: middle; float: right; '><a href='http://localhost:8080/ecell1/viewInvestorProfile'>Profile</a></li><li style='vertical-align: middle; float: right; '><a href='http://localhost:8080/ecell1/searchHome.html'>View Pitch</a></li><li style='vertical-align: middle; float: right; '><a href='investor.html'>Home</a></li></ul></nav>\n<h2>Pitch Details</h2><table id='customers'><thead><tr><th>Founder Name</th><th>Company Name</th><th>Valuation</th><th>Category</th><th>Due Diligence Status</th><th>Current Ask</th></tr></thead>");
            out.println("<tbody style=\"border: 1px solid black; text-align: center;\">");
            int i=1;

  

            while(rs.next()){
                out.println("<tr>");
                String name = rs.getString("fname");
                out.print("<td>"+name+"</td>");
                String ele=rs.getString("cname");
                out.print("<td>"+ele+"</td>");
                out.print("<td>"+rs.getString("valuation")+"</td>");
                out.print("<td>"+rs.getString("category")+"</td>"); 
                out.print("<td>"+rs.getString("dd_status")+"</td>");
                out.print("<td>"+rs.getString("current_ask")+"</td>");
                String url ="http://localhost:8080/ecell1/getPitch";
                out.print("<td><form action = '" + url + "' id=\"detailsForm\" name=\"detailsForm\" method=\"GET\"><input type=\"hidden\" id=\"cname\" name=\"cname\" value=\""+ele+"\"/><input type=\"submit\" value=\"More Details\"/></form></td>");
                out.println("</tr>");    
                i++;           
            }

            rs.close();
            stm.close();
            con.close();

            out.println("</tbody>");
            out.println("<br><br><br><br><br><br><br><br><br><br><br><br><br></body>\n</html>");
        }
        catch(SQLException e){
            System.out.println(e);
            out.println("<body>Database Error</body>");
            out.println("</html>");
            
        }
        catch(Exception e){
            System.out.println(e);
            out.println("<body>Viewing of record Unsuccesfull</body>");
            out.println("</html>");
            
        }
    }
}