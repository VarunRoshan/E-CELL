import java.io.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class login extends HttpServlet{
    
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/ecell";

    static final String USER = "root";
    static final String PASSWORD = "vikash1234";

    String fname, cname, phone_no, cofounder, valuation, ebita, sales_2019, sales_2020, sales_2021, sales_2022, sales_2023, month_1, month_2, month_3, month_4, month_5, month_6, cac, cog, operations, misc, net_profit, gross_profit, video_url, category, founder_role, founder_equity, investor_equity, current_ask;

    public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        String title = "View Records";

        out.println( 
        "<!DOCTYPE html>\n<html>\n<head>\n<title>"+title+"</title>\n<meta charset='UTF-8'>\n</head>"
        );

        try{
            Class.forName(JDBC_DRIVER);

            Connection con = DriverManager.getConnection(DB_URL,USER,PASSWORD);
            Statement stm = con.createStatement();
            String sql;
            String email = req.getParameter("email");
            String role = req.getParameter("role");
            sql = "SELECT count(*) FROM " + req.getParameter("role") + " WHERE password='" +  req.getParameter("password") + "' and email='" + email + "'";
        
            //sql = "SELECT * from investor";
            out.println(sql);
            out.println(email);
            ResultSet rs = stm.executeQuery(sql);

            HttpSession session = req.getSession();
            session.setAttribute("email1", email);
            //out.println(rs.next());
            String url = "";
            while(rs.next()){
                var count = rs.getString("count(*)");
                out.println(count);
                
                if(role.equals("investor"))
                    url = "investor.html";
                else
                    url = "founder.html";
                if(Integer.parseInt(count) < 1)
                    url = "error.html";
            }
            //out.println(url);
            
            
            //String url = "pitch1.html?fname=" + fname +  "&cname=" + cname +  "&phone_no=" + phone_no + "&cofounder=" + cofounder + "&valuation=" + valuation + "&ebita=" + ebita + "&sales_2019=" + sales_2019 + "&sales_2020=" + sales_2020 + "&sales_2021=" + sales_2021 + "&sales_2022=" + sales_2022 + "&sales_2023=" + sales_2023 + "&month_1=" + month_1 + "&month_2=" + month_2 + "&month_3=" + month_3 + "&month_4=" + month_4 + "&month_5=" + month_5 + "&month_6=" + month_6 + "&cac=" + cac + "&cog=" + cog + "&operations=" + operations + "&misc=" + misc + "&net_profit=" + net_profit + "&gross_profit=" + gross_profit + "&video_url=" + video_url + "&category=" + category + "&founder_role=" + founder_role + "&founder_equity=" + founder_equity + "&investor_equity=" + investor_equity + "&dd_status=" + status + "&current_ask=" + current_ask + "&email=" + mail ;

            // req.setAttribute("id1", num1);
            // req.setAttribute("id2", num2);
            // req.setAttribute("id3", num3);
            // req.setAttribute("id4", num4);
            // req.getRequestDispatcher("/random1.html").forward(req,res);

            
            res.sendRedirect(url);
                
            rs.close();
            stm.close();
            con.close();



            //res.sendRedirect(url);

        }
        catch(SQLException e){
            System.out.println(e);
            String url = "http://localhost:8080/ecell1/error.html";
            //res.sendRedirect(url);
        }
        catch(Exception e){
            System.out.println(e);
            req.getRequestDispatcher("/login.html");
            String url = "http://localhost:8080/ecell1/error.html";
            //res.sendRedirect(url);
        }
    }
}