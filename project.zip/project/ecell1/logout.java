import java.io.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class logout extends HttpServlet{
    
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/ecell";

    static final String USER = "root";
    static final String PASSWORD = "vikash1234";

    public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{

        HttpSession session = req.getSession(false);
        session.invalidate();
        res.sendRedirect("login.html");
    }
}