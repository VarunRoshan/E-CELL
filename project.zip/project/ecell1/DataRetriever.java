// import java.sql.Connection;
// import java.sql.DriverManager;
// import java.sql.ResultSet;
// import java.sql.Statement;
// import java.util.ArrayList;
// import java.util.List;

// public class DataRetriever {
    
//     public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{
        
//         try {
//             // Load the JDBC driver
//             Class.forName("com.mysql.jdbc.Driver");
            
//             // Connect to the database
//             String url = "com.mysql.cj.jdbc.Driver";
//             String user = "root";
//             String password = "vikash1234";
//             Connection conn = DriverManager.getConnection(url, user, password);
            
//             // Execute SQL query
//             Statement stmt = conn.createStatement();
//             ResultSet rs = stmt.executeQuery("Select * from ");
            
//             // Store results in list of objects
//             List<DataObject> data = new ArrayList<>();
//             while (rs.next()) {
//                 int count = rs.getInt("count");
//                 String category = rs.getString("category");
//                 data.add(new DataObject(category, count));

//                 req.
//             }
            
//             // Close resources
//             rs.close();
//             stmt.close();
//             conn.close();
            
//             // Pass data to JavaScript code via console log
//             System.out.println("Data: " + data.toString());
            
//         } catch (Exception e) {
//             e.printStackTrace();
//         }
//     }
// }

// class DataObject {
//     String category;
//     int count;
    
//     public DataObject(String category, int count) {
//         this.category = category;
//         this.count = count;
//     }
    
//     public String getCategory() {
//         return category;
//     }
    
//     public int getCount() {
//         return count;
//     }
    
//     @Override
//     public String toString() {
//         return "{category: " + category + ", count: " + count + "}";
//     }
// }



import java.io.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class DataRetriever extends HttpServlet{
    
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/ecell";

    static final String USER = "root";
    static final String PASSWORD = "vikash1234";

    int num1, num2, num3, num4;

    public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        String title = "View Records";

        out.println( 
        "<!DOCTYPE html>\n<html>\n<head>\n<title>"+title+"</title>\n<meta charset='UTF-8'>\n</head>"
        );

        try{
            Class.forName(JDBC_DRIVER);

            Connection con = DriverManager.getConnection(DB_URL,USER,PASSWORD);

            Statement stm = con.createStatement();
            String sql;
            sql = "SELECT * FROM random WHERE num1=1";
            
            ResultSet rs = stm.executeQuery(sql);


            out.println("<body><h2>Patient Records</h2><table><thead><tr><th>ID</th><th>Name</th><th>Age</th><th>Gender</th><th>Address</th><th>Marital Status</th><th>Date of Visit</th></tr></thead>");
            out.println("<h1>Patient Management System</h1><aside><ul><li><a href='http://localhost:8080/patientDetails/add.html'>    Add Record</a></li><li><a href='http://localhost:8080/patientDetails/update.html'> Update Record</a></li><li><a href='http://localhost:8080/patientDetails/delete.html'> Delete Record</a></li><li><a href='http://localhost:8080/patientDetails/View'>        View Record</a></li><li><a href='http://localhost:8080/patientDetails/search.html'> Search a Record</a></li></ul></aside>");
            out.println("<tbody>");

            

            while(rs.next()){
                num1 = rs.getInt("num1");
                num2 = rs.getInt("num2");
                num3 = rs.getInt("num3");
                num4 = rs.getInt("num4");

                out.println(num1);   
                out.println(num2);   
                out.println(num3);   
                out.println(num4);           
            }

            // req.setAttribute("id1", num1);
            // req.setAttribute("id2", num2);
            // req.setAttribute("id3", num3);
            // req.setAttribute("id4", num4);
            // req.getRequestDispatcher("/random1.html").forward(req,res);

            String url = "random1.html?num1=" + num1 +  "&num2=" + num2 + "&num3=" + num3 + "&num4=" + num4;
            res.sendRedirect(url);
                
            rs.close();
            stm.close();
            con.close();

            out.println("</tbody>");
            out.println("Searched for a  record Successfully");
            out.println("</body>\n</html>");
        }
        catch(SQLException e){
            System.out.println(e);
            out.println("<body>Database Error</body>");
            out.println("</html>");
        }
        catch(Exception e){
            System.out.println(e);
            out.println("<body>Searching of record Unsuccesfull</body>");
            out.println("</html>");
        }
    }
}