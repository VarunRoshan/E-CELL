import java.io.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class add2 extends HttpServlet{
    
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/ecell";

    static final String USER = "root";
    static final String PASSWORD = "vikash1234";

    public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        String title = "Add Record";

        out.println( 
        "<!DOCTYPE html>\n<html>\n<head>\n<title>"+title+"</title>\n<meta charset='UTF-8'>\n</head>"
        );

        try{
            Class.forName(JDBC_DRIVER);

            Connection con = DriverManager.getConnection(DB_URL,USER,PASSWORD);

            Statement st = con.createStatement();
            String sql;

            sql = "SELECT count(*) FROM investor where email = '"+ req.getParameter("email") +"'";
            
            
            ResultSet rs = st.executeQuery(sql);

            

            while(rs.next()){
                if(Integer.parseInt(rs.getString("count(*)")) > 0){
                    res.sendRedirect("emailRegisterError.html");
                }
            }

            PreparedStatement stm = con.prepareStatement("INSERT INTO investor VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");
            stm.setString(1,req.getParameter("fname"));
            stm.setString(2,req.getParameter("lname"));
            stm.setString(3,req.getParameter("age"));
            stm.setString(4,req.getParameter("nationality"));
            stm.setString(5,req.getParameter("email"));
            stm.setString(6,req.getParameter("phone_no"));
            stm.setString(7,req.getParameter("aadhar"));
            stm.setString(8,req.getParameter("pan"));
            stm.setString(9,req.getParameter("education"));
            stm.setString(10,req.getParameter("password"));
            stm.setString(11,req.getParameter("currcomp"));
            stm.setString(12,req.getParameter("awards"));
            stm.setString(13,req.getParameter("dspec"));

            stm.executeUpdate();

            stm.close();
            con.close();

            res.sendRedirect("http://localhost:8080/ecell1/success.html");
        }
        catch(SQLException e){
            System.out.println(e);
            out.println("<body>Database Error</body>");
            out.println("</html>");
        }
        catch(Exception e){
            System.out.println(e);
            out.println("<body>Addition of record Unsuccesfull</body>");
            out.println("</html>");
        }
    }
}