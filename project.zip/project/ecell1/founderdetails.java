import java.io.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class founderdetails extends HttpServlet{
    
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/ecell";

    static final String USER = "root";
    static final String PASSWORD = "vikash1234";

    public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        String title = "View Records";

        out.println("<!DOCTYPE html>\n<html>\n<head><link rel='stylesheet' href='index.css'>\n<title>"+title+"</title>\n<meta charset='UTF-8'>\n</head>");

        try{
            Class.forName(JDBC_DRIVER);

            Connection con = DriverManager.getConnection(DB_URL,USER,PASSWORD);

            Statement stm = con.createStatement();
            String sql;
            sql = "SELECT * FROM founder where fname = \'"+req.getParameter("fname")+"\'";        
            ResultSet rs = stm.executeQuery(sql);


            out.println("<body><h2>Personal Details</h2><table id='customers'>");
            out.println("<tbody>");
            int i=1;

            while(rs.next()){
                out.print("<tr><td>First Name</td><td>"+rs.getString("fname")+"</td></tr>");
                out.print("<tr><td>Last Name<td>"+rs.getString("lname")+"</td></tr>");                
                out.print("<tr><td>Age</td><td>"+rs.getString("age")+"</td></tr>");
                out.print("<tr><td>Nationality</td><td>"+rs.getString("nationality")+"</td></tr>");
                out.print("<tr><td>Email</td><td>"+rs.getString("email")+"</td></tr>"); 
                out.print("<tr><td>Phone No</td><td>"+rs.getString("phone_no")+"</td></tr>");
                out.print("<tr><td>Aadhar</td><td>"+rs.getString("aadhar")+"</td></tr>");
                out.print("<tr><td>Pan</td><td>"+rs.getString("pan")+"</td></tr>"); 
                out.print("<tr><td>Education</td><td>"+rs.getString("education")+"</td></tr>");

                out.print("<tr><td>Bio</td><td>"+rs.getString("bio")+"</td></tr>");
                out.print("<tr><td>Previous Company</td><td>"+rs.getString("pvcomp")+"</td></tr>");
                out.print("<tr><td>Work/Domain Experience</td><td>"+rs.getString("wexp")+"</td></tr>"); 
                     
            }

            rs.close();
            stm.close();
            con.close();

            out.println("</tbody>");
            out.println("</body>\n</html>");
        }
        catch(SQLException e){
            System.out.println(e);
            out.println("<body>Database Error</body>");
            out.println("</html>");
        }
        catch(Exception e){
            System.out.println(e);
            out.println("<body>Viewing of record Unsuccesfull</body>");
            out.println("</html>");
        }
    }
}